import React from "react";

interface Props {}

const Verify = (props: Props) => {
  return <div>Verify</div>;
};

export default Verify;
