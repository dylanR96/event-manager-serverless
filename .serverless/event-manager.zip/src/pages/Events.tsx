import React from "react";

interface Props {}

const Events = (props: Props) => {
  return <div>Events</div>;
};

export default Events;
