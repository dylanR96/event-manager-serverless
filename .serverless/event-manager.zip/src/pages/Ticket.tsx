import React from "react";

interface Props {}

const Ticket = (props: Props) => {
  return <div>Ticket</div>;
};

export default Ticket;
