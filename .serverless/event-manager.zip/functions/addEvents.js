import { DynamoDB } from "@aws-sdk/client-dynamodb";
import { events } from "../events/events";

const region = "eu-north-1";

const client = new DynamoDB({ region });

export const createEvents = async (events) => {
  const params = {
    TableName: "Event",
    Item: events,
  };
  client.putItem(params, (err, data) => {
    if (err) {
      console.error(err);
    } else {
      console.log(data);
    }
  });
};
